import React from 'react'
import { Button, Segment, Grid, Header } from 'semantic-ui-react'

function GamesDashboard() {
  return (
    <div>
      <Grid>
      <Grid.Column width={8}>
      <Segment><a href='http://gamebucket1.s3-website.us-east-2.amazonaws.com' target="_blank"><Button>Click here to launch One Player Pong!</Button></a></Segment>
      <Segment><a href='http://gamebucket2.s3-website.us-east-2.amazonaws.com/' target="_blank"><Button>Click here to launch Two Player SnakeTron!</Button></a></Segment>
      <Segment><Header>More Game(s) Coming Soon!</Header></Segment>
      </Grid.Column>
      </Grid>
    </div>
  )
}

export default GamesDashboard
