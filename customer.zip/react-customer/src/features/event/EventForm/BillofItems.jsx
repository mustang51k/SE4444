import React, { Component } from 'react'
import BillElement from './BillElement'

 class BillofItems extends Component {
  render() {
    const {bills} = this.props;
    console.log('can u see', bills)
    return (
      <div>
          {bills && bills.items.map((item) => (
          <BillElement key ={item.id} item={item}/>
        ))}
      </div>
    )
  }
}
export default BillofItems
