import React, { Component } from 'react'
import { connect } from 'react-redux'
import { firestoreConnect} from 'react-redux-firebase'
import { Grid, Form, Field, TextArea, Button, Input, Radio, Segment, Header, Item} from 'semantic-ui-react'


const mapState = state => ({
  ActiveBills: state.firestore.ordered.ActiveBill,
  loading: state.async.loading
})

const actions = {
  //tryCoupon,
  //payBill
}



class PayForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      payment1: 0,
      tip1: 0,
      payment2: 0,
      tip2: 0,
      payment3: 0,
      tip3: 0,
      payment4: 0,
      tip4: 0,
      totalPay: 0,
      totalTip: 0
      
    }
  }
 /* state = {
    payMembers : [
      {
        payment: 0,
        tip: 0
      },
      {
        payment: 0,
        tip: 0
      },
      {
        payment: 0,
        tip: 0
      },
      {
        payment: 0,
        tip: 0
      }
    ]
  }*/

handleChange = (e, { value }) => this.setState({ value })
handleChange2 = (e, { value2 }) => this.setState({ value2 })

handleChange3 = (e, { name, value }) => {
  this.setState({ [name]: value })
}

pay1Change = (evt) => {
  console.log(evt.target.value);
  this.setState({ payment1: Number(evt.target.value) });
}

tip1Change = (evt) => {
  console.log(typeof evt.target.value);
  this.setState({ tip1: Number(evt.target.value) });
}

pay2Change = (evt) => {
  console.log(evt.target.value);
  this.setState({ payment2: Number(evt.target.value) });
}

tip2Change = (evt) => {
  console.log(typeof evt.target.value);
  this.setState({ tip2: Number(evt.target.value) });
}

pay3Change = (evt) => {
  console.log(evt.target.value);
  this.setState({ payment3: Number(evt.target.value) });
}

tip3Change = (evt) => {
  console.log(typeof evt.target.value);
  this.setState({ tip3: Number(evt.target.value) });
}

pay4Change = (evt) => {
  console.log(evt.target.value);
  this.setState({ payment4: Number(evt.target.value) });
}

tip4Change = (evt) => {
  console.log(typeof evt.target.value);
  this.setState({ tip4: Number(evt.target.value) });
}

addPayment =(event)=> {
  let x = this.state.payment1 + this.state.payment2 + this.state.payment3 + this.state.payment4
  this.setState({totalPay: x })
}

addTip =(event)=> {
  let x = this.state.tip1 + this.state.tip2 + this.state.tip3 + this.state.tip4
  this.setState({totalTip: x })
}

filterTable = () => {

}

/*calcTendered = () => {
  let total = this.state.payMembers.reduce((prev, cur) => prev + cur.payment, 0);
  return total
}*/

calcTotal = (bills) => {
  let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
  return total
}

calc10 = (bills) => {
  let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
  return (0.1*total).toFixed(2)
}

calc15 = (bills) => {
  let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
  return (0.15*total).toFixed(2)
}

calc20 = (bills) => {
  let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
  return (0.2*total).toFixed(2)
}

handleCoupon = () =>{

}

handleSubmit = () =>{


}

  render() {
    const { ActiveBills } = this.props
    const { value, value2 } = this.state
    
    return (
      <div>
          <Grid>
            <Grid.Column width={10}>
            <Segment>
              <Form>
                <Form.Field>
                  <label><Header>Coupon</Header></label>
                  <input placeholder='Please enter a code if you have one' />
                </Form.Field>
                <Form.Field color='green'control={Button}>Try Code</Form.Field>
              </Form>
              </Segment>
              <Segment> 
              <Form>
              <Header>Cash or Credit?</Header> 
                <Form.Group>
                <Form.Field
                    control={Radio}
                    label='Cash'
                    value='cash'
                    checked={value === 'cash'}
                    onChange={this.handleChange}
                  />
                  <Form.Field
                    control={Radio}
                    label='Credit'
                    value='credit'
                    checked={value === 'credit'}
                    onChange={this.handleChange}
                  />
                </Form.Group>
                { value === 'credit' && 
                    <Form.Input
                       type='number'
                       label='Credit'
                       placeholder='Enter 16 digit Credit Card number'
                      />}
                 <Header>How would you like to split the check?</Header>    
                 <Form.Group>
                <Form.Field
                    control={Radio}
                    label='One Way'
                    value2={1}
                    checked={value2 === 1}
                    onChange={this.handleChange2}
                  />
                  <Form.Field
                    control={Radio}
                    label='Two Ways'
                    value2={2}
                    checked={value2 === 2}
                    onChange={this.handleChange2}
                  />
                  <Form.Field
                    control={Radio}
                    label='Three Ways'
                    value2={3}
                    checked={value2 === 3}
                    onChange={this.handleChange2}
                  />
                  <Form.Field
                    control={Radio}
                    label='Four Ways'
                    value2={4}
                    checked={value2 === 4}
                    onChange={this.handleChange2}
                  />
                </Form.Group>
                {ActiveBills &&
                <Item.Group>
                <Item>Suggested 10%: ${this.calc10(ActiveBills)}</Item>
                 <Item>Suggested 15%: ${this.calc15(ActiveBills)}</Item>
                 <Item> Suggested 20%: ${this.calc20(ActiveBills)}</Item>
                 </Item.Group>}
                  { value2 === 1 && 
                    <div>
                     <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay1Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip1Change}
                      />
                      </Segment> 
                      </div>}

                  { value2 === 2 && 
                    <div>
                    <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay1Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip1Change}
                      />
                      </Segment>
                      <Segment>
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay2Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip2Change}
                      />
                      </Segment>
                      </div>}

                  { value2 === 3 && 
                    <div>
                    <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay1Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip1Change}
                      />
                      </Segment>
                      <Segment>
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay2Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip2Change}
                      />
                      </Segment>
                      <Segment>
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay3Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip3Change}
                      />
                      </Segment>
                      </div>}

                    { value2 === 4 && 
                    <div>
                    <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay1Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip1Change}
                      />
                      </Segment>
                      <Segment>
                      <Form.Input 
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay2Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip2Change}
                      />
                      </Segment>
                      <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay3Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip3Change}
                      />
                      </Segment>
                      <Segment>
                    <Form.Input
                       type='number'
                       min = '0'
                       label='Payment'
                       placeholder='Enter amount'
                       onChange={this.pay4Change}
                      />
                      <Form.Input
                       type='number'
                       min = '0'
                       label='Tip'
                       placeholder="Enter a tip, we won't judge if you don't"
                       onChange={this.tip4Change}
                      />
                      </Segment>
                      </div>}
                      <Form.Field color='green'control={Button}>Submit Payment</Form.Field>
              </Form>
              </Segment>
            </Grid.Column>
            <Grid.Column width={6}>
               {ActiveBills && 
              <Segment><Header>Total Owed: ${this.calcTotal(ActiveBills)}</Header></Segment>
              }
              <Button onClick={this.addPayment}>Update Pay</Button>
              <Button onClick={this.addTip}>Update Tip</Button>
              <Segment><Header>Your Amount: ${this.state.totalPay} </Header></Segment> 
              <Segment><Header>Your Tip: ${this.state.totalTip} </Header></Segment> 
            </Grid.Column>
          </Grid>
      </div>
    )
  }
}

export default connect(mapState, actions)(firestoreConnect([{collection: 'ActiveBill'}])(PayForm));