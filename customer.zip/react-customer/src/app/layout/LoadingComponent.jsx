import React from 'react'
import { Dimmer, Loader } from 'semantic-ui-react'

//if something is using async for loading, I use this component to dim the background and show a loading animation
const LoadingComponent = ({inverted}) => {
  return (
    <Dimmer inverted={inverted} active={true}>
        <Loader content = 'Loading...'/>
    </Dimmer>
  )
}

export default LoadingComponent
