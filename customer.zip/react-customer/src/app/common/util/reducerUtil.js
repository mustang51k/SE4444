export const createReducer = (initialState, fnMap) => {
    return (state = initialState, {type, payload}) => {
        const handler = fnMap[type]

        return handler ? handler(state, payload) : state
    }
}

//reducer utility function for the updating of state with applicable payloads