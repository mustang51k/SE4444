import { createStore, applyMiddleware, compose } from 'redux'
import { composeWithDevTools } from 'redux-devtools-extension'
import { reactReduxFirebase, getFirebase} from 'react-redux-firebase'
import { reduxFirestore, getFirestore } from 'redux-firestore'
import thunk from 'redux-thunk'
import rootReducer from '../reducers/rootReducer'
import firebase from '../config/firebase'

//for react redux firestore user credentials
const rrfConfig = {
    userProfile: 'users',
    attachAuthIsReady: true,
    useFirestoreForProfile: true
}
//middleware composer, integrates fireStore, fireBase, thunk (which is for async actions)
//allows for sgate management through redux's state system with the root reducer, store, and actions
export const configureStore = (preloadedState) => {
    const middlewares = [thunk.withExtraArgument({getFirebase, getFirestore})]
    const middlewareEnhancer = applyMiddleware(...middlewares)

    const storeEnhancers = [middlewareEnhancer]

    const composedEnhancer = composeWithDevTools(
        ...storeEnhancers, 
        reactReduxFirebase(firebase, rrfConfig),
        reduxFirestore(firebase)
        )
//current store with all accumulated redux state
    const store = createStore(
        rootReducer,
        preloadedState,
        composedEnhancer
    )
//hot module update of the root reducer ir for whatever reason it does not match with current store state
    if (process.env.NODE_ENV !== 'production') {
        if (module.hot) {
            module.hot.accept('../reducers/rootReducer.js', () => {
                const newRootReducer = require('../reducers/rootReducer').default
                store.replaceReducer(newRootReducer)
            })
        }
    }

    return store;
}