launched with npm,
to save space we dont include the node modules folder
