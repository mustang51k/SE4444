const sampleMenu = {
    menu: [
        {
        id : 1,
        productImage:"https://www.thewholesomedish.com/wp-content/uploads/2018/07/Best-Lasagna-550-500x375.jpg",
        name:"Lasagna",
        description:"Eat me",
        catgeory:"Entree",
        price:1000},

        {id : 2,
        productImage:"https://www.thewholesomedish.com/wp-content/uploads/2018/07/Best-Lasagna-550-500x375.jpg",
        name:"Also Lasagna",
        description:"Eat them",
        catgeory:"Entree",
        price:1000},

        {id : 3,
        productImage:"https://www.thewholesomedish.com/wp-content/uploads/2018/07/Best-Lasagna-550-500x375.jpg",
        name:"Also Also Lasagna",
        description:"Eat yourself",
        catgeory:"Entree",
        price:1000},

       
    ]
}

export default sampleMenu