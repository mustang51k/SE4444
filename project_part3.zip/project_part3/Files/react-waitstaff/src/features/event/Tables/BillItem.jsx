import React, { Component } from 'react'
import { Item, Segment } from "semantic-ui-react";

class BillItem extends Component {
  render() {
    const { bill } = this.props
    return (
      <div>
        <Segment.Group>
        <Segment>
          item: {bill.name}
        </Segment>
        <Segment>
          price: {bill.price}
        </Segment>
        <Segment secondary>
          catgeory: {bill.category}
        </Segment>
      </Segment.Group>
      </div>
    )
  }
}

export default BillItem