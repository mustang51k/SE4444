import { toastr } from "react-redux-toastr";
import {
  CREATE_EVENT,
  DELETE_EVENT,
  UPDATE_EVENT,
  FETCH_EVENT,
  FETCH_MENU
} from "./eventConstants";
import {
  asyncActionStart,
  asyncActionFinish,
  asyncActionError
} from "../async/asyncActions";
import { fetchSampleData, fetchSampleMenu } from "../../app/data/mockApi";

//for handling table help
export const helpDone = table => {
  return async (dispatch, getState, { getFirestore }) => {
    const firestore = getFirestore();
    table.help = false;

    console.log("help try", table);
    try {
      await firestore.update(`TableStatus/${table.id}`, table);
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//for button for refill is done
export const refillDone = table => {
  return async (dispatch, getState, { getFirestore }) => {
    const firestore = getFirestore();
    table.refill = false;

    console.log("help try", table);
    try {
      await firestore.update(`TableStatus/${table.id}`, table);
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//handle the button reset table
export const resetDone = table => {
  return async (dispatch, getState, { getFirestore }) => {
    const firestore = getFirestore();
    table.refill = false;
    table.active = false;
    table.help = false;
    table.ready = false;

    console.log("help try", table);
    try {
      await firestore.update(`TableStatus/${table.id}`, table);
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//button to set the food delivered message
export const readyDone = table => {
  return async (dispatch, getState, { getFirestore }) => {
    const firestore = getFirestore();

    table.ready = false;

    console.log("ready try", table);
    try {
      await firestore.update(`TableStatus/${table.id}`, table);
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//fetching events
export const fetchEvents = events => {
  return {
    type: FETCH_EVENT,
    payload: events
  };
};

export const fetchMenu = menu => {
  return {
    type: FETCH_MENU,
    payload: menu
  };
};

//for event creation
export const createEvent = event => {
  return async dispatch => {
    try {
      dispatch({
        type: CREATE_EVENT,
        payload: {
          event
        }
      });
      toastr.success("Success!", "Event has been created");
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//updates event
export const updateEvent = event => {
  return async dispatch => {
    try {
      dispatch({
        type: UPDATE_EVENT,
        payload: {
          event
        }
      });
      toastr.success("Success!", "Event has been updated");
    } catch (error) {
      toastr.error("Oops", "Something went wrong");
    }
  };
};

//deletes event
export const deleteEvent = eventId => {
  return {
    type: DELETE_EVENT,
    payload: {
      eventId
    }
  };
};

//for loading
export const loadEvents = () => {
  return async dispatch => {
    try {
      dispatch(asyncActionStart());
      let events = await fetchSampleData();
      dispatch(fetchEvents(events));
      dispatch(asyncActionFinish());
    } catch (error) {
      console.log(error);
      dispatch(asyncActionError());
    }
  };
};

//loads the menu
export const loadMenu = () => {
  return async dispatch => {
    try {
      dispatch(asyncActionStart());
      let menu = await fetchSampleMenu();
      dispatch(fetchMenu(menu));
      dispatch(asyncActionFinish());
    } catch (error) {
      console.log(error);
      dispatch(asyncActionError());
    }
  };
};
