import React, {Component} from 'react'
import { Header, Segment } from 'semantic-ui-react'


class EventActivity extends Component {
  render () {
    const {menu} = this.props
    return (
      <div>
        {menu.map((item) => (
          <testItem key ={item.id} item={item}/>
        ))}
        
      </div>
    )
  }
}

export default EventActivity 
