let snake;
let food;
let w;
let h;
let res = 2;
let gameover = false;
let size = 20;
let winnerIsOne = false; 
let noWinner = false;
let menu = true;
let paused = false;

function setup() {
  
  createCanvas(800, 800);
  w = floor(width/res);
  h = floor(height/res);
  frameRate(12);
  snake = new Snake();
  snake.setColor(225, 225, 0);
  snake2 = new Snake();
  snake2.setColor(0, 0, 225);
  foodLocation();
  textSize(32);
  textAlign(CENTER);
}

function foodLocation() {
  let x = floor(random(w/size))*size;
  let y = floor(random(h/size))*size;
  food = createVector(x, y);
  
}

function endGame() {
    let x1 = snake.body[snake.body.length - 1].x;
    let y1 = snake.body[snake.body.length - 1].y;
    let x2 = snake2.body[snake2.body.length - 1].x;
    let y2 = snake2.body[snake2.body.length - 1].y;

    if (x1 == x2 && y1 == y2) {
        noWinner = true;
        return true;
    }

    for (let i = 0; i < snake.body.length - 1; i++) {
        let part = snake.body[i];
        if (part.x == x1 && part.y == y1) {
            winnerIsOne = true;
            return true;
        } 
        if (part.x == x2 && part.y == y2) {
            winnerIsOne = false;
            return true;
        }
    }
    
    for (let i = 0; i < snake2.body.length - 1; i++) {
        let part = snake2.body[i];
        if (part.x == x1 && part.y == y1) {
            winnerIsOne = true;
            return true;
        }
        if (part.x == x2 && part.y == y2) {
            winnerIsOne = false;
            return true;
        }
    }



    return false;
}

function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        let xdir = snake.xdir;
        if(xdir != size)
            snake.setDir(-size, 0);
    } else if (keyCode === RIGHT_ARROW) {
        let xdir = snake.xdir;
        if (xdir != -size)
            snake.setDir(size, 0);
    } else if (keyCode === DOWN_ARROW) {
        let ydir = snake.ydir;
        if (ydir != -size)
            snake.setDir(0, size);
    } else if (keyCode === UP_ARROW) {
        let ydir = snake.ydir;
        if (ydir != size)
            snake.setDir(0, -size);
    } else if(key == 'a') {
        let xdir = snake2.xdir;
        if (xdir != size)
            snake2.setDir(-size, 0);
    } else if (key == 'd') {
        let xdir = snake2.xdir;
        if (xdir != -size)
            snake2.setDir(size, 0);
    } else if (key == 's') {
        let ydir = snake2.ydir;
        if (ydir != -size)
            snake2.setDir(0, size);
    } else if (key == 'w') {
        let ydir = snake2.ydir;
        if (ydir != size)
            snake2.setDir(0, -size);
    } else if (key == 'r' && gameover) {
        gameover = false;
        noWinner = false;
        winnerIsOne = false;
        snake = new Snake();
        snake.setColor(255, 255, 0);
        snake2 = new Snake();
        snake2.setColor(0, 0, 255);
        foodLocation();
    } else if (key == 'c') {
        menu = true;
    } else if (key == 'p') {
        paused = !paused;
    } else if (key == ' ') {
        menu = false;
    }

}

function draw() {
    scale(res);
    noStroke();
    if (menu) {
        background(98, 178, 0);
        fill(225, 0, 0);
        text("Welcome to Snake Tron:", w / 2, 75);
        text("Player 1: Arrow Keys", w / 2, 125);
        text("Player 2: WASD", w / 2, 175);
        text("View Controls: C", w / 2, 225);
        text("Pause: P", w / 2, 275);
        text("Press Space to Begin", w / 2, 350);
    } else if (paused) {
        text('Paused', w / 2, h / 2);
    } else if (!gameover) {
        background(98, 178, 0);
        if (snake.eat(food) || snake2.eat(food)) {
            foodLocation();
        }
        if (!paused) {
            snake.update();
            snake2.update();
        }
        snake.show(size);
        snake2.show(size);

        fill(160, 82, 45);
        rect(food.x + 9, food.y + 1, 2, 10);
        fill(225, 0, 0);
        ellipse(food.x+7, food.y + 12, 15, 18);
        ellipse(food.x + 13, food.y + 12, 15, 18);

        if (endGame()) {
            gameover = true;
            if (noWinner) {
                fill(225, 0, 0);
                text('Draw:', w / 2, h / 2 - 15);
                text('No-one Wins', w / 2, h / 2 + 15);
            } else if (winnerIsOne) {
                fill(0, 0, 255);
                text('Player One Wins:', w / 2, h / 2);
            } else {
                fill(255, 255, 0);
                text('Player Two Wins:', w / 2, h / 2);
            }
        }
    }
}
