class Snake {
    
  
  constructor() {
      this.body = [];
      let size = 20;
    this.body[0] = createVector(floor(random(w/size))*size, floor(random(h/size))*size);
    this.xdir = 0;
    this.ydir = 0;
    this.len = 0; 
    this.timer = 0;
  }

  setColor(red, green, blue) {
      this.colorr = red;
      this.colorg = green;
      this.colorb = blue;
  }

  setDir(x, y) {
  	this.xdir = x;
    this.ydir = y;
  }
  
  update() {
  	let head = this.body[this.body.length-1].copy();
    this.body.shift();
    head.x += this.xdir;
    head.y += this.ydir;
    if (head.x >= w) {
        head.x = 0;
    } else if (head.x <= -1) {
        head.x = w - size;
    } else if (head.y >= h) {
        head.y = 0;
    } else if (head.y <= -1) {
        head.y = h - size;
    }
      
    this.body.push(head);
  }
  
  grow() {
  	let head = this.body[this.body.length-1].copy();
    this.len++;
    this.body.push(head);
  }
  
  eat(pos) {
  	let x = this.body[this.body.length-1].x;
    let y = this.body[this.body.length-1].y;
    if(x == pos.x && y == pos.y) {
      this.grow();
      return true;
    }
    return false;
  }
  
  show(size) {
      this.timer += 1;
      this.timer %= 2;
      let r = this.colorr;
      let g = this.colorg;
      let b = this.colorb;
      fill(r, g, b);
      if (this.body.length > 1) {
          if (this.body[0].y == 0 && !(this.body[0].x - this.body[1].x == -size || this.body[0].x - this.body[1].x == size || this.body[0].y - this.body[1].y == -size)) {
              triangle(this.body[0].x + size / 2, this.body[0].y + size, this.body[0].x + size, this.body[0].y, this.body[0].x, this.body[0].y);
          } else if (this.body[0].x == w - size && !(this.body[0].y - this.body[1].y == size || this.body[0].y - this.body[1].y == -size || this.body[0].x - this.body[1].x == size)) {
              triangle(this.body[0].x, this.body[0].y + size / 2, this.body[0].x + size, this.body[0].y + size, this.body[0].x + size, this.body[0].y); 
          } else if (this.body[0].y == h - size && !(this.body[0].x - this.body[1].x == -size || this.body[0].x - this.body[1].x == size || this.body[0].y - this.body[1].y == size)) {
              triangle(this.body[0].x + size / 2, this.body[0].y, this.body[0].x + size, this.body[0].y + size, this.body[0].x, this.body[0].y + size);
          } else if (this.body[0].x == 0 && !(this.body[0].y - this.body[1].y == size || this.body[0].y - this.body[1].y == -size || this.body[0].x - this.body[1].x == -size)) {
              triangle(this.body[0].x + size, this.body[0].y + size / 2, this.body[0].x, this.body[0].y + size, this.body[0].x, this.body[0].y);
          }
          if (this.body[0].y - this.body[1].y == size) { 
              triangle(this.body[0].x + size / 2, this.body[0].y + size, this.body[0].x + size, this.body[0].y, this.body[0].x, this.body[0].y); //
          } else if (this.body[0].x - this.body[1].x == -size) {  
              triangle(this.body[0].x, this.body[0].y + size / 2, this.body[0].x + size, this.body[0].y + size, this.body[0].x + size, this.body[0].y); //
          } else if (this.body[0].y - this.body[1].y == -size) { 
              triangle(this.body[0].x + size / 2, this.body[0].y, this.body[0].x + size, this.body[0].y + size, this.body[0].x, this.body[0].y + size); // 
          } else if (this.body[0].x - this.body[1].x == size) { 
              triangle(this.body[0].x + size, this.body[0].y + size / 2, this.body[0].x, this.body[0].y + size, this.body[0].x, this.body[0].y); //
          }
      } 
    for (let i = 1; i < this.body.length-1; i++) {
      noStroke();
      rect(this.body[i].x, this.body[i].y, size, size);
      }
    let x = this.body[this.body.length - 1].x;
    let y = this.body[this.body.length - 1].y;
    ellipse(x + size / 2, y + size / 2, size * 1.5, size * 1.5);
    fill(98, 178, 0);
    if (this.ydir == size) {
        if (this.timer == 1) {
            triangle(x + size / 2, y + size / 2, x + (3 * size / 4) + 2, y + size + 6, x + size / 4 - 2, y + size + 6);
        }
        fill(1, 1, 1);
        ellipse(x + size / 4, y + size / 4, 3, 3);
    } else if (this.xdir == size) {
        if (this.timer == 1) {
            triangle(x + size / 2, y + size / 2, x + size + 5, y + (3 * size / 4) + 2, x + size + 5, y + size / 4 - 2);
        }
        fill(1, 1, 1);
        ellipse(x + size / 4, y + 3 * size / 4, 3, 3);
    } else if (this.ydir == -size) {
        if (this.timer == 1) {
            triangle(x + size / 2, y + size / 2, x + (3 * size / 4) + 2, y - 6, x + size / 4- 2, y - 6 );
        }
        fill(1, 1, 1);
        ellipse(x + 3 * size / 4, y + 3 * size / 4, 3, 3);
    } else {
        if (this.timer == 1) {
            triangle(x + size / 2, y + size / 2, x-5, y + (3*size/4)+2, x-5, y + size/4-2);
        }
        fill(1, 1, 1);
        ellipse(x + 3 * size / 4, y + size / 4, 3, 3);
    }
  }

}