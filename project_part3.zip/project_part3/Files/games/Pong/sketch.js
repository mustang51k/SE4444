let paddle;
let ball;
let rez;
let w;
let h;
let gameover;
let movespeed = 5;
let menu = true;
let paused = false;
//generates canvas, draws necessary sprites
function setup() {
    rez = 2;
  createCanvas(1200, 900);
  w = floor(width/rez);
  h = floor(height/rez);
  frameRate(60);
  paddle = new Paddle(w, h);
  ball = new Ball(w, h);
  gameover = false;
  textSize(48);
  textAlign(CENTER);
  textFont("Bit5x3");
}
//ends the game
function endGame() {
    return ball.x < 0;
}
//all associated keypresses
function keyPressed() {
    if (keyCode === DOWN_ARROW) {
        paddle.move(movespeed);
    } else if (keyCode === UP_ARROW) {
        paddle.move(-movespeed);
    } else if (key == 'r' && gameover) {
        gameover = false;
        paddle = new Paddle(w, h);
        ball = new Ball(w, h);
    } else if (key == 'c') {
        menu = true;
    } else if (key == 'p') {
        paused = !paused;
    } else if (key == ' ') {
        menu = false;
    }
}
//all associated key releases and their actions
function keyReleased() {
    if (keyCode === DOWN_ARROW) {
        paddle.move(0);
    }
    if (keyCode === UP_ARROW) {
        paddle.move(0);
    }
}
//draws text based on state of the game using coordinates of rendered plane and RGB fill
function draw() {
    scale(rez);
    if (menu) {
        background(0, 0, 0);
        fill(255, 255, 255);
        text("Controls:", w / 2, 50);
        text("Move Paddle", w / 2, 100);
        text("Arrow Keys", w / 2, 150);
        text("View Controls: C", w / 2, 200);
        text("Pause: P", w / 2, 250);
        text("Press Space", w / 2, 325);
        text("to Begin", w / 2, 375);
    } else if (!gameover) {
        background(0, 0, 0);
        for (let i = 5; i < w; i += 20) {
            rect(i, 40, 10, 10);
        }
        if (paused) {
            text("Paused", w / 2, h / 2);
        } else {
            paddle.update();
            ball.update(paddle);
        }
        paddle.show();
        ball.show();
        if (endGame()) {
            fill(255, 255, 255);
            gameover = true;
            text("GAME OVER", w / 2, h / 2);
        }
        
    }
}
