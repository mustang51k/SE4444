//ball class for the paddle to hit
class Ball {
    //ball constructor including size, shape, position, etc
    constructor(wid, hei) {
        this.w = wid;
        this.h = hei;
        this.rad = 10;
        this.x = w/2;
        this.y = h/2;
        this.angle = (3*PI/4)+random(PI/2);
        this.speed = 2.5;
    }
//updates position of ball
    update(paddle) {
        if (this.collide(paddle)) {
            this.angle = PI - this.angle + random(PI / 6) - PI / 12;
            paddle.score();
            this.speed += .15;
        } else if (this.x + cos(this.angle) * this.speed + this.rad > w) {
            this.angle = PI - this.angle;
        } else if (this.y + sin(this.angle) * this.speed < 50) {
            this.angle = TWO_PI - this.angle;
        } else if (this.y + sin(this.angle) * this.speed + this.rad > h) {
            this.angle = TWO_PI - this.angle;
        }
        this.x += cos(this.angle)*this.speed;
        this.y += sin(this.angle)*this.speed;
    }
//collision of ball with paddle
    collide(paddle) {
        return this.x <= paddle.x + paddle.width &&
                this.x + this.rad >= paddle.x &&
                this.y <= paddle.y + paddle.height &&
                this.y + this.rad >= paddle.y;
    }

    show() {
        rect(this.x, this.y, this.rad, this.rad);
    }
}