//class for paddle
class Paddle {
    
  //constructor for size of paddle and its current position
  constructor(w, h) {
    this.width = 10;
    this.height = 75;
    this.w = w;
    this.h = h;
    this.x = 20;
    this.y = (this.h-this.height)/2;
    this.dir = 0;
    this.points = 0;
  }
//allows for direction change
  move(direction) {
      this.dir = direction;
  }
//updates score
  score() {
      this.points++;
  }
//upfates position of paddle
  update() {
      this.y += this.dir;
      if (this.y + this.height > this.h) {
          this.y = this.h-this.height;
      }
      if (this.y < 50) {
          this.y = 50;
      }
  }
  
  show(size) {
      fill(255, 255, 255);
      rect(this.x, this.y, this.width, this.height);
      text(this.points, w/2, 36);
  }

}