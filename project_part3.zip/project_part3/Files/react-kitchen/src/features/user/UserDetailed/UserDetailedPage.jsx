import React from 'react'

function UserDetailedPage() {
  return (
    <div>
      
    </div>
  )
}

export default UserDetailedPage
