import React from 'react'

function AboutPage() {
  return (
    <div>
      
    </div>
  )
}

export default AboutPage
