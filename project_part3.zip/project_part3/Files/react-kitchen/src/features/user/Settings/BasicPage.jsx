import React from 'react'

function BasicPage() {
  return (
    <div>
      
    </div>
  )
}

export default BasicPage
