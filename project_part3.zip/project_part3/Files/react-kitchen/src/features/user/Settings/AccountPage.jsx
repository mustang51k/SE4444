import React from 'react'

function AccountPage() {
  return (
    <div>
      
    </div>
  )
}

export default AccountPage
