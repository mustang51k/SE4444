import React from 'react'

function PhotosPage() {
  return (
    <div>
      
    </div>
  )
}

export default PhotosPage
