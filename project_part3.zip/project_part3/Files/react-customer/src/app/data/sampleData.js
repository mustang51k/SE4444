//ock data fo testing, no longer used


const sampleData = {
    events: [
        {
          id: 1,
          name: 'Lasagna',
          price: 10
        },
        {
          id: 2,
          name: 'Tea',
          price: 1
        }
      ]
}

export default sampleData