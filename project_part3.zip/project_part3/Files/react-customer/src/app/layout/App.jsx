import React, { Component } from "react";
import { Container } from "semantic-ui-react";
import { Route, Switch } from 'react-router-dom'
import EventDashBoard from "../../features/event/EventDashboard/EventDashBoard";
import NavBar from "../../features/nav/NavBar/NavBar";
import EventForm from '../../features/event/EventForm/EventForm'
import ReceiptPage from '../../features/event/EventForm/ReceiptPage'
import GamesDashboard from '../../features/user/PeopleDashboard/GamesDashboard' 
import HomePage from '../../features/home/HomePage'
import TestComponent from '../../features/testarea/TestComponent'
import ModalManager from '../../features/modals/ModalManager'
import PayForm from '../../features/event/EventForm/PayForm'
/*
App is the root component and all components leads back to it
Uses ModalManager to handle Modal popups where rleevant
the Routing allows pushes to url routes that can be called from child components
the Switch allows for onl the current route to render and blocks all other routes from trying to render
simultaneously

App is passed to index.js for final execution
*/

class App extends Component {
  render() {
    return (
      <div>
        <ModalManager/>
        <Switch>
          <Route exact path='/' component={HomePage}/>
        </Switch>

        <Route path="/(.+)" render={() => (
          <div>
            <NavBar />
            <Container className="main">
              <Switch>
                <Route path='/events' component={EventDashBoard}/>
                <Route path='/test' component={TestComponent}/>
                <Route path='/manage/:id' component={EventForm}/>
                <Route path='/games' component={GamesDashboard}/>
                <Route path='/createEvent' component={EventForm}/>
                <Route path='/pay' component={PayForm}/>
                <Route path='/receipt' component={ReceiptPage}/>
              </Switch> 
            </Container>
          </div>
        )}/>
        
      </div>
    );
  }
}

export default App;
