export const LOGIN_USER = "LOGIN_USER"
export const SIGN_OUT_USER = "SIGN_OUT_USER"