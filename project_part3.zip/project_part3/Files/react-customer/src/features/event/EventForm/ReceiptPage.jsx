import React, { Component } from 'react'
import { openModal } from '../../modals/modalActions'
import { connect } from 'react-redux'
import { Button, Grid, Segment, Header, Form, Field } from 'semantic-ui-react'
import { firestoreConnect} from 'react-redux-firebase';
import  BillofItems  from './BillofItems'

const mapState = (state) => ({ //getting data from the store
    data: state.test.data,
    loading: state.test.loading,
    ActiveBills: state.firestore.ordered.ActiveBill
})

const actions = {
  openModal
}

 class ReceiptPage extends Component {
    
    tryModal = () => {
        if(Math.random() > 0.8)
        {
            this.props.openModal('TestModal')
        }
        else
        {
            return alert("Sorry You did not win")
        }          
      }

  render() {
    const { ActiveBills } = this.props;
    console.log('hello', ActiveBills)
    return (
      <div>
          
          <Grid>
              <Grid.Column width={8}>
              <Segment><Header>Do you get a prize?</Header></Segment>
                <Button onClick={this.tryModal} color='teal' content='Click Me!'/>
              </Grid.Column>
              <Grid.Column width={8}>
                    <Header>Receipt of Payment</Header>
                {ActiveBills && <BillofItems bills={ActiveBills[0]}/> }
              </Grid.Column>
          </Grid>

      </div>
    )
  }
}

export default connect(mapState, actions)(firestoreConnect([{collection: 'ActiveBill'}])(ReceiptPage));