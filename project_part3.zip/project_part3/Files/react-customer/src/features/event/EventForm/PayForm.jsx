import React, { Component } from "react";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { Link } from 'react-router-dom';
import {
  Grid,
  Form,
  Field,
  TextArea,
  Button,
  Input,
  Radio,
  Segment,
  Header,
  Item
} from "semantic-ui-react";
import { tryCoupon, payBill } from '../eventActions'
//getting state data from redux store
const mapState = state => ({
  ActiveBills: state.firestore.ordered.ActiveBill,
  loading: state.async.loading
});
//getting actions from redux actions
const actions = {
  tryCoupon,
  payBill
};

//huge class with lots going on, facilitates dynamic payment for multiple people
class PayForm extends Component {
  //initial local state definition
  state = {
    payMembers: [
      {
        payment: 0,
        tip: 0
      }
    ]
  };
  //handle change for radios
  handleChange = (e, { value }) => this.setState({ value });
  //handle change for payMember, changes with the number 
  //of payMembers in existence, up to 4, 
  changeNumberOfPayMembers = (e, { value }) => {
    // create copy of payMembers
    let payMembers = this.state.payMembers.concat();
    if (payMembers.length === value) return;
    else if (payMembers.length > value) {
      payMembers = payMembers.filter((val, i) => i < value);
    } else {
      while (payMembers.length < value) {
        payMembers.push({
          payment: 0,
          tip: 0
        });
      }
    }
    this.setState({ payMembers });
  };
//state update fr the ith payMemeber
  handlePayMemberChange = (i, field) => {
    return (e, { value }) => {
      let payMembers = this.state.payMembers.concat();
      payMembers[i][field] = Number(value);
      this.setState({ payMembers });
    };
  };

  filterTable = () => {};
//calculate money tendered from guests
  calcTendered = () => {
    let total = this.state.payMembers.reduce(
      (prev, cur) => prev + cur.payment,
      0
    );
    return total;
  };
//calculate tip given from guests
  calcTip = () => {
    let total = this.state.payMembers.reduce(
      (prev, cur) => prev + cur.tip,
      0
    );
    return total;
  };
  //calc total owed from ActiveBill
  calcTotal = bills => {
    let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
    return total;
  };
//calc10 calc15 and calc20 calculate suggested tip for for the total amount owed
  calc10 = bills => {
    let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
    return (0.1 * total).toFixed(2);
  };

  calc15 = bills => {
    let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
    return (0.15 * total).toFixed(2);
  };

  calc20 = bills => {
    let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
    return (0.2 * total).toFixed(2);
  };

  handleCoupon = () => {


  };
//handler for submit, sends total paid, total tips, table id and item length
  handleSubmit = (total, tips, table, length) => {

    const newPay = {
      TableID : table,
      gross: (total+tips),
      noItems: length,
      tip: tips,
      total: total
    }
    this.props.payBill(newPay)

  };

  render() {
    const { ActiveBills } = this.props; //destructuring as needed from state and props
    const { value, payMembers } = this.state;
    const numberOfPayMembers = payMembers.length;
    const totalPay = this.calcTendered() //total amount tendered called here
    const totalTip = this.calcTip() //total tip called here
/*
Very large render, renders the tables and the forms and accepts the input ands runs a changestate on 
input entered
when amount entered equals amount owed, the submit button appears
*/
    return (
      <div>
        <Grid>
          <Grid.Column width={10}>
            <Segment>
              <Form>
                <Form.Field>
                  <label>
                    <Header>Coupon</Header>
                  </label>
                  <input placeholder="Please enter a code if you have one" />
                </Form.Field>
                <Form.Field color="green" control={Button}>
                  Try Code
                </Form.Field>
              </Form>
            </Segment>
            <Segment>
              {ActiveBills &&
              <Form>
                <Header>Cash or Credit?</Header>
                <Form.Group>
                  <Form.Field
                    control={Radio}
                    label="Cash"
                    value="cash"
                    checked={value === "cash"}
                    onChange={this.handleChange}
                  />
                  <Form.Field
                    control={Radio}
                    label="Credit"
                    value="credit"
                    checked={value === "credit"}
                    onChange={this.handleChange}
                  />
                </Form.Group>
                {value === "credit" && (
                  <Form.Input
                    type="number"
                    label="Credit"
                    placeholder="Enter 16 digit Credit Card number"
                  />
                )}
                <Header>How would you like to split the check?</Header>
                <Form.Group>
                  <Form.Field
                    control={Radio}
                    label="One Way"
                    value={1}
                    checked={payMembers.length === 1}
                    onChange={this.changeNumberOfPayMembers}
                  />
                  <Form.Field
                    control={Radio}
                    label="Two Ways"
                    value={2}
                    checked={payMembers.length === 2}
                    onChange={this.changeNumberOfPayMembers}
                  />
                  <Form.Field
                    control={Radio}
                    label="Three Ways"
                    value={3}
                    checked={payMembers.length === 3}
                    onChange={this.changeNumberOfPayMembers}
                  />
                  <Form.Field
                    control={Radio}
                    label="Four Ways"
                    value={4}
                    checked={payMembers.length === 4}
                    onChange={this.changeNumberOfPayMembers}
                  />
                </Form.Group>
                {ActiveBills && (
                  <Item.Group>
                    <Item>Suggested 10%: ${this.calc10(ActiveBills)}</Item>
                    <Item>Suggested 15%: ${this.calc15(ActiveBills)}</Item>
                    <Item> Suggested 20%: ${this.calc20(ActiveBills)}</Item>
                  </Item.Group>
                )}
                {payMembers.map((payMember, i) => {
                  return (
                    <Segment>
                      <Form.Input
                        type="number"
                        min="0"
                        label="Payment"
                        placeholder="Enter amount"
                        name={`payMembers[${i}].payment`}
                        value={payMembers[i].payment}
                        onChange={this.handlePayMemberChange(i, "payment")}
                      />
                      <Form.Input
                        type="number"
                        min="0"
                        label="Tip"
                        placeholder="Enter a tip, we won't judge if you don't"
                        name={`payMembers[${i}].tip`}
                        value={payMembers[i].tip}
                        onChange={this.handlePayMemberChange(i, "tip")}
                      />
                    </Segment>
                  );
                })}
                {totalPay === this.calcTotal(ActiveBills) &&
                <Button as={Link} to='/receipt' color="green" onClick={() => this.handleSubmit(totalPay, totalTip , 1, ActiveBills[0].items.length)}>
                  Submit Payment
                </Button>}
              </Form>}
            </Segment>
          </Grid.Column>
          <Grid.Column width={6}>
            {ActiveBills && (
              <Segment>
                <Header>Total Owed: ${this.calcTotal(ActiveBills)}</Header>
              </Segment>
            )}
            <Segment>
              <Header>Your Amount: ${this.calcTendered()} </Header>
            </Segment>
            <Segment>
              <Header>Your Tip: ${this.calcTip()} </Header>
            </Segment>
          </Grid.Column>
        </Grid>
      </div>
    );
  }
}
//connection back to redux actions and mapState
export default connect(
  mapState,
  actions
)(firestoreConnect([{ collection: "ActiveBill" }])(PayForm));
