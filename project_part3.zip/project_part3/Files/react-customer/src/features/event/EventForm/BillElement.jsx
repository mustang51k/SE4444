import React, { Component } from 'react'
import { Segment, Item} from 'semantic-ui-react'

class BillElement extends Component {
  render() {
    const {item} = this.props;
    return (
      
          <Segment>
          <Item.Group>
            <Item>
              
              <Item.Content>
                          
                  <Item.Header> {item.name}</Item.Header>
    
                <Item.Description>
                  <span clearing>${item.price}</span>
                </Item.Description>
              </Item.Content>
            </Item>
          </Item.Group>
        </Segment>
        
      
    )
  }
}

export default BillElement
