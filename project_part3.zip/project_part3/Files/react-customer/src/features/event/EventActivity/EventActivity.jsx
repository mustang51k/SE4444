import React, {Component} from 'react'
import { connect } from 'react-redux'
import { Header, Segment, Button, Form, Input, TextArea } from 'semantic-ui-react'
import OrderItem from './OrderItem'
import cuid from 'cuid'
import {  submitOrder, deleteEvent, addToBill } from '../eventActions'
import { firestoreConnect } from 'react-redux-firebase';

const mapState = (state) => ({ //getting data from the redux store
  loading: state.test.loading,
  activeBills: state.firestore.ordered.ActiveBill
})
 //actions from redux actions
const actions = {
  submitOrder,
  addToBill,
  deleteEvent
}

class EventActivity extends Component {
  //local state constructor, used for the inputted notes
  constructor(){
    super()
    this.state = { notes: '' }
  }
  
  
  //state changer for notes, updates with newly inputted values
  handleChange = (e, { name, value }) => {
    //console.log("Im called")
    this.setState({ [name]: value })
  }
 //submit new order handler, takes the shopping cart items and the current ActiveBills to
 //event Actions for sending to firestore
  submitNewOrder = (items, bills) => {
        
   
    if(items.length > 0)
    {            
        this.props.submitOrder(items, this.state.notes); //new order
        this.props.addToBill(items, bills[0]); //append to ActiveBills
        items.map((item) => (this.props.deleteEvent(item.id))) //delete current items after sent to firebase
    }
}
//Calc current total owed for display
calcTotal = (bills) => {
  let total = bills[0].items.reduce((prev, cur) => prev + cur.price, 0);
  return total
}

  render () {
    const {deleteItem, events, activeBills} = this.props //destructuring props
    const {notes} = this.state //destructuring state

    //html/css portion, renders shopping cart list and components
    return (
      <div>
        {activeBills && 
        <Segment><Header>Overall Total: ${this.calcTotal(activeBills)}</Header></Segment>}
        <div>
          <Form.Group >
          <Form.Input 
          control={TextArea} 
          placeholder='Tell us about any changes or allergies'
          name='notes'
          value={notes}
          onChange={this.handleChange}
           />
          </Form.Group>
        </div>
          
        {events &&
        events.map((item) => (
        
          <OrderItem key ={item.id} item={item}  deleteItem = {deleteItem}/>
        ))}

        
          <Button onClick={() => this.submitNewOrder(events, activeBills)} color="green" float="left" content="Submit Order"/>
      </div>
      
    )
  }
}
//connection to redux and firestore, pulls in ActiveBill collection
export default connect(mapState, actions)(firestoreConnect([{collection: 'ActiveBill'}])(EventActivity));
