import React, { Component } from 'react'
import EventListItem from './EventListItem'

//component of eventDashboard, the event in question here is the menu list,
//which is mapped out and the individual compoments are rendered in the child component

class EventList extends Component {

  render() {
    const {menu, deleteEvent, arr} = this.props;
    return (
      
      <div>
      {menu &&
        menu.map(
          item =>
            item.category === arr && (
              <EventListItem
                key={item.id}
                item={item}
                deleteEvent={deleteEvent}
              />
            )
        )}
    </div>
    )
  }
}
export default EventList 