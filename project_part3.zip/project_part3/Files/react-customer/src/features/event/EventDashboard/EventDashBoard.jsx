import React, { Component } from 'react'
import { connect } from 'react-redux'
import { firestoreConnect} from 'react-redux-firebase';
import { reduxForm, Field } from 'redux-form'
import { Grid, Segment, Form, Button, Item } from 'semantic-ui-react';
import EventList from '../EventList/EventList';
import { deleteEvent, loadMenu } from '../eventActions'
import  LoadingComponent  from '../../../app/layout/LoadingComponent'
import { combineValidators, hasLengthLessThan} from 'revalidate'
import EventActivity from '../EventActivity/EventActivity'
import EventForm from '../EventForm/EventForm'
import TextArea from '../../../app/common/form/TextArea'
import { stat } from 'fs';
//state from redux store
const mapState = state => ({
  events: state.events,
  menu: state.firestore.ordered.menu,
  loading: state.async.loading
})
//action from redux actions
const actions = {
  deleteEvent 
}

const validate = hasLengthLessThan(255)({message: 'Must be less than 255 characters.'})
  


class EventDashBoard extends Component {

  handleDeleteEvent = eventId => () => {
    this.props.deleteEvent(eventId)
    /*const updatedEvents = this.state.events.filter(e => e.id !== eventId); //creates new array of events that dont match event id
    this.setState({
        events: updatedEvents
    })*/
  }

  
  
  //Root render for both the Menu and theShopping cart
  //Menu on the left and shopping cart on the right
  //Menu is EventList and Shopping Cart is Event Activity
  

  render() {
    //const {selectedEvent} = this.state;
    const {menu, loading, events} = this.props; //destructured props

    //console.log(events)
    const tempTotal = events.reduce((prev, cur) => prev + cur.price, 0); //calcs current total of the shopping cart
   
    if (loading) return <LoadingComponent inverted={true}/>
    
    return (
      <div>
        <Grid>
        <Grid.Column width={9}>
            <h2>Appetizer</h2>
            <EventList
              deleteEvent={this.handleDeleteEvent}
              menu={menu}
              arr="Appetizer"
            />
            <h2>Entree</h2>
            <EventList
              deleteEvent={this.handleDeleteEvent}
              menu={menu}
              arr="Entree"
            />
            <h2>Kid's Meals</h2>
            <EventList
              deleteEvent={this.handleDeleteEvent}
              menu={menu}
              arr="Kid's Meals"
            />
            <h2>Dessert</h2>
            <EventList
              deleteEvent={this.handleDeleteEvent}
              menu={menu}
              arr="Dessert"
            />
            <h2>Drinks</h2>
            <EventList
              deleteEvent={this.handleDeleteEvent}
              menu={menu}
              arr="Drinks"
            />
          </Grid.Column>
            <Grid.Column width={7}>
               <Segment header>Current Order Total: ${tempTotal}</Segment>
               <EventActivity events={events} deleteItem={this.handleDeleteEvent} />
            </Grid.Column>
        </Grid>
      </div>
    )
  }
}
//firestore, redux connection, pulls in menu collection from firestore
export default connect(mapState, actions)(firestoreConnect([{collection: 'menu'}])(EventDashBoard));