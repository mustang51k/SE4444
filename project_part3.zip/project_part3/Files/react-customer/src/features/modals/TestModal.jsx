import React from 'react'
import { connect } from 'react-redux'
import { Modal } from 'semantic-ui-react'
import { closeModal } from './modalActions'

//this is the modal called with the coupon code
const actions = {
  closeModal
}
//50/50 chance for either a free app or dessert
const decideValue = () => {
  if(Math.random() > 0.5)
    return "Appetizer: code is FREEAPP"
  else
    return "Dessert: code is FREEDESSERT"
}
const TestModal = ({closeModal}) => {
    return(
            <Modal closeIcon="close" open={true} onClose={closeModal}>
              <Modal.Header>A Coupon!</Modal.Header>
              <Modal.Content>
                <Modal.Description>
                  <p>Congratulations! You've Won A Free {decideValue()}</p>
                </Modal.Description>
              </Modal.Content>
            </Modal>
    )
}

export default connect(null, actions)(TestModal)